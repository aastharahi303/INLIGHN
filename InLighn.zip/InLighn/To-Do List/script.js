document.addEventListener("DOMContentLoaded", function () {
    const addTaskBtn = document.getElementById("addTaskBtn");
    const taskForm = document.getElementById("taskForm");
    const saveTaskBtn = document.getElementById("saveTask");
    const clearTaskBtn = document.getElementById("clearTask");
    const clearAllBtn = document.getElementById("clearAll");
    const taskList = document.getElementById("taskList");
    const taskNameInput = document.getElementById("taskName");
    const taskDateTimeInput = document.getElementById("taskDateTime");

    // Show Task Form
    addTaskBtn.addEventListener("click", function () {
        taskForm.style.display = "block";
    });

    // Save Task
    saveTaskBtn.addEventListener("click", function () {
        const taskName = taskNameInput.value.trim();
        const taskDateTime = taskDateTimeInput.value;

        if (taskName === "" || taskDateTime === "") {
            alert("Please enter task name and date/time.");
            return;
        }

        const li = document.createElement("li");
        li.innerHTML = `${taskName} - ${taskDateTime} 
            <button class="btn red delete-task">Clear</button>`;

        taskList.appendChild(li);

        // Clear inputs
        taskNameInput.value = "";
        taskDateTimeInput.value = "";

        // Add delete event to new button
        li.querySelector(".delete-task").addEventListener("click", function () {
            li.remove();
        });
    });

    // Clear Individual Task
    taskList.addEventListener("click", function (e) {
        if (e.target.classList.contains("delete-task")) {
            e.target.parentElement.remove();
        }
    });

    // Clear Form Inputs
    clearTaskBtn.addEventListener("click", function () {
        taskNameInput.value = "";
        taskDateTimeInput.value = "";
    });

    // Clear All Tasks
    clearAllBtn.addEventListener("click", function () {
        taskList.innerHTML = "";
    });
});

console.log("YOU CAN DO IT");
